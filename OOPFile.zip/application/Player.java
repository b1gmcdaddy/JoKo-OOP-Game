package application;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

public class Player {
    private static final int PLAYER_SIZE = 20;
    private static final int JUMP_HEIGHT = 10;
    private static final double GRAVITY = 5;
    private static final double PLAYER_GRAVITY = 1.1;
    private static final double PLAYER_SPEED = 3;
    private int life;

    private Rectangle player;
    private boolean isJumping;
    private boolean isMovingLeft;
    private boolean isMovingRight;
    private double velocityY;
    private Scene scene;
    

    public Player() {
        player = new Rectangle(PLAYER_SIZE, PLAYER_SIZE, Color.BLUE);
        player.relocate(390, 810);

        isJumping = false;
        isMovingLeft = false;
        isMovingRight = false;
        velocityY = 0;
        life = 3;
    }

    public Rectangle getNode() {
        return player;
    }

    public double getWidth() {
        return player.getWidth();
    }

    public double getHeight() {
        return player.getHeight();
    }

    public double getX() {
        return player.getLayoutX();
    }

    public double getY() {
        return player.getLayoutY();
    }

    public void setY(double y) {
        player.setLayoutY(y);
    }

    public Scene getScene() {
        return scene;
    }

    public void setScene(Scene scene) {
        this.scene = scene;
    }

    public void jump() {
        if (!isJumping) {
            isJumping = true;
            velocityY = -JUMP_HEIGHT;
        }
    }

    public void startMovingLeft() {
        isMovingLeft = true;
    }

    public void stopMovingLeft() {
        isMovingLeft = false;
    }

    public void startMovingRight() {
        isMovingRight = true;
    }

    public void stopMovingRight() {
        isMovingRight = false;
    }

    public void stopFalling(double groundY) {
        player.setLayoutY(groundY);
        velocityY = 0;
        isJumping = false;
    }
    
    public void resetPosition() {
    	player.relocate(390, 810);
    }
    
    public void falldeath() {
    	player.relocate(390, 810);		
    }
    
    public void decreaseLife() {
        life--;
        System.out.println("Remaining Lives: " + life);
        if (life < 0) {
            System.out.println("Game Over");
            // Add game over logic here
            
        }
    }
    
    public void update() {
        if (isMovingLeft) {
            player.setLayoutX(player.getLayoutX() - PLAYER_SPEED);
        } else if (isMovingRight) {
            player.setLayoutX(player.getLayoutX() + PLAYER_SPEED);
        }

        if (isJumping) {
            velocityY += PLAYER_GRAVITY;
            player.setLayoutY(player.getLayoutY() + velocityY);
        } else {
            player.setLayoutY(player.getLayoutY() + GRAVITY);
        }
    }

    public boolean intersects(StackPane other) {
        return player.getBoundsInParent().intersects(other.getBoundsInParent());
    }
}
