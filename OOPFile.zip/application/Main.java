package application;
	
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Main extends Application {
    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 850;
    private static final int GROUND_HEIGHT = 20;

    private Pane root;
    private Player player;
    private Platform ground;
    private Platform platform1;
    private Platform platform2;
    private Platform platform3;
    private Platform platform4;
    private Platform platform5;
    private Platform platform6;
    private Platform platform7;
    private Traps trap;
    private Traps trap1;
    private Traps trap2;
    private Traps trap3;

    @Override
    public void start(Stage primaryStage) {
        root = new Pane();
        Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
        primaryStage.setTitle("Escape From Hell");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
        
        Image backgroundImage = new Image("file:src/application/EscapeHellBackground.png");
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT,
                BackgroundRepeat.REPEAT, null, new BackgroundSize(WINDOW_WIDTH, WINDOW_HEIGHT, false, false, false, false));
        root.setBackground(new Background(background));

        player = new Player();
        ground = new Platform(200, WINDOW_HEIGHT - GROUND_HEIGHT, 390, GROUND_HEIGHT, "file:src/application/hell_platform1.jpg");
        platform1 = new Platform(670, (WINDOW_HEIGHT - GROUND_HEIGHT), 500, 15, "file:src/application/hell_platform1.jpg");
        platform2 = new Platform(0, (WINDOW_HEIGHT - GROUND_HEIGHT), 130, 15, "file:src/application/hell_platform1.jpg");
        platform3 = new Platform(WINDOW_WIDTH - 50, (WINDOW_HEIGHT - GROUND_HEIGHT) - 50, 200, 15, "file:src/application/hell_platform1.jpg");
        platform4 = new Platform(630, 740, 70, 15, "file:src/application/hell_platform1.jpg");
        platform5 = new Platform(700, (WINDOW_HEIGHT - GROUND_HEIGHT) - 155, 200, 15, "file:src/application/hell_platform1.jpg");
        platform6 = new Platform(430, 710, 130, 15, "file:src/application/hell_platform1.jpg");
        platform7 = new Platform(0, 740, 70, 15, "file:src/application/hell_platform1.jpg");
        trap = new Traps(730, 810, 20, 25, "file:src/application/trap.png");
        trap1 = new Traps(750, 810, 20, 25, "file:src/application/trap.png");
        trap2 = new Traps(700, 800-20, 30, 30, "file:src/application/trap.png");
        trap3 = new Traps(800, 850-20-116, 90, 25, "file:src/application/trap.png");
        
        root.getChildren().addAll(player.getNode(), ground.getNode(), 
        		platform1.getNode(), platform2.getNode(), platform3.getNode(), 
        		platform4.getNode(), platform5.getNode(), platform6.getNode(), 
        		platform7.getNode(),
        		trap.getNode(), trap1.getNode(), trap2.getNode(), trap3.getNode());

        scene.setOnKeyPressed(e -> {
            KeyCode keyCode = e.getCode();
            if (keyCode == KeyCode.SPACE) {
                player.jump();
            } else if (keyCode == KeyCode.A) {
                player.startMovingLeft();
            } else if (keyCode == KeyCode.D) {
                player.startMovingRight();
            }
        });

        scene.setOnKeyReleased(e -> {
            KeyCode keyCode = e.getCode();
            if (keyCode == KeyCode.A) {
                player.stopMovingLeft();
            } else if (keyCode == KeyCode.D) {
                player.stopMovingRight();
            }
        });
        

        AnimationTimer gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                update();
            }
        };
        gameLoop.start();
    }

    private void update() {
        player.update();
        trap.checkTrapCollision(player);
        trap1.checkTrapCollision(player);
        trap2.checkTrapCollision(player);
        trap2.rotate(180);
        trap3.checkTrapCollision(player);
        trap3.rotate(180);
        
        if(player.getY() > WINDOW_HEIGHT) {
        	player.falldeath();
        	player.decreaseLife();
        }
        
        if (player.intersects(ground.getNode())) {
            player.stopFalling(ground.getY() - player.getHeight());
        } else if (player.intersects(platform1.getNode())) {
            player.stopFalling(platform1.getY() - player.getHeight());
        } else if (player.intersects(platform2.getNode())) {
            player.stopFalling(platform2.getY() - player.getHeight());
        } else if (player.intersects(platform3.getNode())) {
            player.stopFalling(platform3.getY() - player.getHeight());
        } else if (player.intersects(platform4.getNode())) {
            player.stopFalling(platform4.getY() - player.getHeight());
        } else if (player.intersects(platform5.getNode())) {
            player.stopFalling(platform5.getY() - player.getHeight());
        } else if (player.intersects(platform6.getNode())) {
            player.stopFalling(platform6.getY() - player.getHeight());
        }  else if (player.intersects(platform7.getNode())) {
            player.stopFalling(platform7.getY() - player.getHeight());
        } 
        
    }

    public static void main(String[] args) {
        launch(args);
    }
}
